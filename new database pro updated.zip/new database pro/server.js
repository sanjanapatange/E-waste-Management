const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');

const app = express();
const port = 3003;

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

// Serve the HTML file
app.get('/contact.html', (req, res) => {
    res.sendFile(path.join(__dirname, 'contact.html'));
});

// Handle form submission
app.post('/submit-request', (req, res) => {
    const { name, email, phone_number, pickup_point, quantity_kg, message } = req.body;

    // Handle the form data (e.g., save to database, send email, etc.)
    console.log('Form submission received:');
    console.log(`Name: ${name}`);
    console.log(`Email: ${email}`);
    console.log(`Phone Number: ${phone_number}`);
    console.log(`Pickup Point: ${pickup_point}`);
    console.log(`Quantity (kg): ${quantity_kg}`);
    console.log(`Message: ${message}`);

    // Send a response back to the client
    res.send('Thank you for contacting us! We will get in touch with you shortly.');
});

app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});
